var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "background-color" : "rgb(255,102,0)",
      "font-size" : 12,
      "text-valign" : "center",
      "text-halign" : "center",
      "width" : 90.0,
      "border-color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "color" : "rgb(0,0,0)",
      "height" : 35.0,
      "background-opacity" : 1.0,
      "border-width" : 0.0,
      "border-opacity" : 1.0,
      "shape" : "ellipse",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[members = 26]",
    "css" : {
      "background-color" : "rgb(51,102,255)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "opacity" : 1.0,
      "font-size" : 10,
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "line-color" : "rgb(132,132,132)",
      "content" : "",
      "line-style" : "solid",
      "text-opacity" : 1.0,
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "target-arrow-shape" : "none",
      "width" : 3.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]